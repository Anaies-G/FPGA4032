clc; clear; close all hidden

a = [3 167 249 1 0 187 37 218 2 15];
x = [4 133 177 0 0 204 136 231 8 153];

y = sum(a.*x);
disp(y)